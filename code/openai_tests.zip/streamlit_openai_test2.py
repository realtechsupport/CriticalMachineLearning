
# Sample openai with streamlit
# April 2023
#--------------------------------------------------------------------------------------------------------
import os, sys
import streamlit as st
import streamlit.components.v1 as components
import numpy
import torch
import openai
import pandas
from torch import nn, optim
from torch.utils.data import DataLoader
from collections import Counter

datapath = '/home/marcbohlen/data/'
authpath = datapath + 'auth/'
authfile = 'myapi.txt'
st.title("openai image generation")

#--------------------------------------------------------------------------------------------------------
# Access OPENAI
# read in the OpenAI key
import json
import requests
gpt_creds = authpath + authfile

file = open(gpt_creds, 'r')
data = file.read()
cdata = json.loads(data)
file.close()
APIkey = (cdata['apikey'])
#print('got the apikey')

# Imagery ----------------------------------------------------------------------------------------------
# create an image with a prompt
import openai
openai.api_key = APIkey
num = 1
bsize = "256x256"
image_urls = []
image_names = []
datasets = []
ideas = ['camping in a dark forest', 'camping with a campfire', 'camping with friends', 'camping with wild animals']

#generate th eimages
i = 0
for idea in ideas:
	response = openai.Image.create(prompt=idea, n=1,size=bsize)
	image_urls.append(response['data'][0]['url'])
	image_names.append('output_' + str(i)+ '.jpg')
	i = i+1

for j in range(0, len(ideas)):
	d = requests.get(image_urls[j]).content
	f = open(datapath + image_names[j], 'wb')
	f.write(d)
	f.close()

#display the images
for k in range(0, len(ideas)):
	st.image(datapath + image_names[k])
	st.caption(ideas[k])

# --------------------------------------------------------------------------------------------------------
